***********18*********
ALTER TABLE `preload_url_task` ADD COLUMN success_indexs varchar(255) DEFAULT "" NOT NULL;
***********17*********
Alter Table vhost_port_tmp Rename To [vhost_port];
***********16*********
Alter Table vhost_port Rename To [vhost_port_old];
***********15*********
INSERT INTO vhost_port_tmp (vhost,port,id,type,host,public_setting,private_setting) SELECT vhost,port,id,type,host,public_setting,private_setting FROM vhost_port;
***********14*********
CREATE TABLE `vhost_port_tmp` (
        [vhost] VARCHAR(255) NOT NULL,
        [port] INTEGER NOT NULL,
        [id] INTEGER NOT NULL,
        [type] INTEGER  NOT NULL ,
        [host] VARCHAR(255) NOT NULL,
        [public_setting] VARCHAR(255) NOT NULL DEFAULT '',
        [private_setting] VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY ([vhost],[id])
);
**********13**********
CREATE TABLE `preload_url_task` (
        [id] INTEGER UNIQUE NOT NULL,
        [success_num] INTEGER DEFAULT 0 NOT NULL,
        [fail_num] INTEGER DEFAULT 0 NOT NULL,
        [start_time] datetime NOT NULL,
        [end_time] datetime  NULL,
        [status] INTEGER DEFAULT 0 NOT NULL
);
**********12**********
CREATE TABLE `vhost_port` (
        [vhost] VARCHAR(255) NOT NULL,
        [port] INTEGER NOT NULL,
        [id] INTEGER NOT NULL,
        [type] INTEGER  NOT NULL ,
        [host] VARCHAR(255) NOT NULL,
        [public_setting] VARCHAR(255) NOT NULL DEFAULT '',
        [private_setting] VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY ([vhost],[port])
);
*********11***********
ALTER TABLE `vhost` ADD COLUMN early_data INTEGER DEFAULT 0;
*********10***********
ALTER TABLE `vhost` ADD COLUMN `node_router` VARCHAR(255) DEFAULT NULL;
*********9************
CREATE TABLE `black_list` (
	[ip] VARCHAR(255) PRIMARY KEY NOT NULL,
	[flags] INTEGER NOT NULL
);
*********8************
DROP TABLE `product_node`;
CREATE TABLE `product_node` (
        [pgid] INTEGER NOT NULL,
        [id] INTEGER  NOT NULL ,
        [master_id] INTEGER  NOT NULL ,       
        [monitor_ip] VARCHAR(255) NOT NULL,
        PRIMARY KEY ([pgid],[id])
);
******7******
DROP TABLE `product_node`;
CREATE TABLE `product_node` (
        [pgid] INTEGER NOT NULL,
        [id] INTEGER  NOT NULL ,
        [master_id] INTEGER  NOT NULL ,       
        [monitor_ip] VARCHAR(255) NOT NULL,
        PRIMARY KEY ([pgid],[id])
);
******6******
CREATE TABLE `product_node` (
        [id] INTEGER  NOT NULL ,
        [pgid] INTEGER NOT NULL,
        [ip] VARCHAR(255) NOT NULL,
        [monitor_ip] VARCHAR(255) NOT NULL,
        PRIMARY KEY ([ip],[id],[pgid])
);
******5******
ALTER TABLE `vhost` ADD COLUMN `pgid_four` INTEGER NOT NULL DEFAULT -1;
CREATE TABLE `port` (
        [id] INTEGER  NOT NULL ,
        [ip] VARCHAR(255) NOT NULL,
        [vhost] VARCHAR(255) NOT NULL,
        [port] INTEGER NOT NULL,
        PRIMARY KEY ([vhost],[id])
);
******4******
ALTER TABLE `vhost` ADD COLUMN `http2` INTEGER NOT NULL DEFAULT 0;
ALTER TABLE `domain` ADD COLUMN `public_setting` TEXT;
ALTER TABLE `domain` ADD COLUMN `private_setting` TEXT;
ALTER TABLE `vhost` ADD COLUMN `log_rotate_time` VARCHAR(255) DEFAULT "0 */1 * * *";
******3******
CREATE TABLE `router_config` (
        [id] INTEGER  NOT NULL ,
        [indexd] INTEGER DEFAULT 0 NOT NULL ,
        [dst_ip] VARCHAR(255) NOT NULL,
        [gateway] TEXT DEFAULT 0 NOT NULL,
        [hash] INTEGER  DEFAULT 0 NOT NULL,
        PRIMARY KEY ([indexd],[id])
);
******0******

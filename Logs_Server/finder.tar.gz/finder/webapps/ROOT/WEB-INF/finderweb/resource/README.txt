# resource 目录结构

resource
    + lang
        + admin
            - en.properties      英文
            - ja.properties      日文
            - zh_cn.properties   中文简体
            - zn_tw.properties   中文繁体
            - xxxxx.properties   其他语言
        - en.properties          英文
        - ja.properties          日文
        - zh_cn.properties       中文简体
        - zn_tw.properties       中文繁体
        - xxxxx.properties       其他语言

## lang 目录内为多语言支持配置文件，默认支持 英文，日文，中文简体，中文繁体；
    语言包加载过程
    1. 加载默认的语言包，默认语言包在.jar文件内，无法修改；如果默认的语言包没有，则加载英文语言包。
    2. 加载 ~/WEB-INF/classes/META-INF/conf/resource/lang/xx.properties
       如果存在则加载并覆盖；如果不存在则使用默认的语言包；

    lang目录内的所有文件都不是必须的，如果没有任何改动，可以全部删除。

## 添加新的语言包
    1. 复制 en.properties，修改文件名为新的语言，例如增加韩语支持的文件名为: ko.properties
    2. 修改 ko.properties, 将对应的英文翻译为韩文；
    3. 重启 tomcat；重启之后如果不生效，请清空浏览器缓存。
